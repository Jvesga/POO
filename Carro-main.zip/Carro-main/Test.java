package ejecutable;

import modelo.Carro;
import controlador.Controlador;
import vista.VentanaPrincipal;


public class Test
{
    public static void main(String[] args) 
    {
        Carro miCarro = null;
        VentanaPrincipal miVentana = new VentanaPrincipal();
        Controlador micontrolador = new Controlador(miVentana, miCarro);

    }
}
