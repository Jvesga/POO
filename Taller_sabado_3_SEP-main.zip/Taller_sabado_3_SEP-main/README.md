# Taller_sabdo_3_SEP
 
# Ejercicio No. 1
Calcular e imprimir el doble de un número X.


![image](https://user-images.githubusercontent.com/102545608/188278804-d30bb366-75bc-4cbc-8888-23c8ee7c2b10.png)
![image](https://user-images.githubusercontent.com/102545608/188278829-d8c8e859-8799-4c9f-b161-b77c92e3bf78.png)


# Ejercicio No. 2
El dueño de una papelería desea un programa que le indique el precio de venta de un artículo dado. El precio se calcula con la siguiente fórmula:
P = precioCosto + ganancia
Donde la ganancia será:
-El 15% si el costo es inferior a $3000
-$500 si el costo está entre $3000 y $6000
-El 25% si el costo supera los $6000.


![image](https://user-images.githubusercontent.com/102545608/188278883-0ae80b74-f785-4b7c-824b-63960ce07e1b.png)
![image](https://user-images.githubusercontent.com/102545608/188278911-48c02301-0dd9-464d-b8b3-49a17ec67afb.png)


# Ejercicio No. 3
Leer un número entero y que determinar si dicho número es de uno, dos o tres dígitos.


![image](https://user-images.githubusercontent.com/102545608/188278989-471a287a-2339-4763-b7d1-2d2a7e989277.png)
![image](https://user-images.githubusercontent.com/102545608/188279031-16025b5c-3cc3-444b-8871-63d28dbd8a7e.png)


# Ejercicio No. 4
Calcular la suma y el promedio de los números pares menores o iguales que un número K leído al comienzo.


![image](https://user-images.githubusercontent.com/102545608/188279071-f11fe595-d969-4f41-be99-f588eddbccc8.png)
![image](https://user-images.githubusercontent.com/102545608/188279074-41b797ed-d521-4888-aad4-87acf4a7ec9a.png)


# Ejercicio No. 5
Leer dos números M y N, luego calcular la suma y el promedio de los múltiplos de 5 que están entre ellos, incluidos M y/o N si es que son múltiplos de 5.


![image](https://user-images.githubusercontent.com/102545608/188279111-bc5ada3c-ca3d-4d5e-bad8-88b9d08ef282.png)
![image](https://user-images.githubusercontent.com/102545608/188279125-e6c36ad3-c2d0-41da-89ac-a8d6e8024fd8.png)


# Ejercicio No. 6
Pedro tiene capital de C1 pesos y Juan uno de C2 pesos. Uniendo los dos capitales no les alcanza para realizar un negocio que requiere una inversión de C3 pesos. Deciden colocar cada uno su capital a ganar intereses. Pedro lo colocó a un interés compuesto del 3% mensual y Juan al 4% mensual. Hacer un programa que averigüe e imprima en cuántos meses, uniendo los dos capitales, pueden hacer el negocio que desean. (Tomado de Carrillo, Elberto (1995). Introducción a los computadores. Problemario Solucionario. Universidad Industrial de Santander.)


![image](https://user-images.githubusercontent.com/102545608/188279196-403e143d-a5bf-47c0-847d-2eb7ec84955f.png)
![image](https://user-images.githubusercontent.com/102545608/188279208-3c55ae49-4700-4df3-a7c3-f929f4324a63.png)
![image](https://user-images.githubusercontent.com/102545608/188279220-ed0f6d76-b425-4e50-8097-fa9b4a34db88.png)


# Ejercicio No. 7
Hacer un programa que tome uno a uno los elementos enteros de un arreglo unidimensional (vector, array) llamado bases ya inicializado y en un segundo arreglo llamado resultados coloque el cuadrado de cada número del arreglo bases en caso de ser par, o el cubo si es impar.


![image](https://user-images.githubusercontent.com/102545608/188279244-ed794f5c-636d-424c-b802-0915d3597065.png)


# Ejercicio No. 8
Leer una matriz M, (arreglo bidimensional) de m filas y n columnas. Los elementos son números enteros aleatorios positivos. Crear e imprimir dos vectores así: el vector A que contenga todos los números pares de la matriz M, y el vector B que contenga los números impares.

![image](https://user-images.githubusercontent.com/102545608/188279270-269d23cf-7fa0-427a-8498-c6b94143a1cf.png)
![image](https://user-images.githubusercontent.com/102545608/188279277-bd0ef980-4bae-459b-818c-102e97dec391.png)
