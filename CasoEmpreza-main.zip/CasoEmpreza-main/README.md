# CasoEmpreza

una empreza desea conocer el total a pagar por conceptos de salarios a sus empleados. Cada empleado trabaja un numero de horas mensuales y recibe una valoracion por esa hora de trabajo. Si el empleado gana menos de dos saliros minimos, entonces recibe un auxilio de transporte, adicionalmente se desea calcular la edad del empleado, apartie de su fecha de nacimiento, y la antiguedad del empleado usando su fecha de ingreso a la empresa. 
